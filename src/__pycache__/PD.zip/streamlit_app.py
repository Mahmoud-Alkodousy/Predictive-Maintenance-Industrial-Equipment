"""
Predictive Maintenance System - Main Application
Clean, refactored version with separated modules
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import plotly.express as px
import time

# Import custom modules
from feature_engineering import process_telemetry
from analysis_tab import render_analysis_tab
from sample_data import create_sample_data
from explainability import ModelExplainer
#from premium_theme import apply_premium_theme

# Page config
st.set_page_config(
    page_title="Predictive Maintenance System",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Model configuration
MODELS_DIR = r"E:\Temp_Projects\Depi-Predictive-Maintenance-Project\data\models"
MODEL_MAP = {
    "LR_24h": "model_24h_LR.joblib",
    "RF_24h": "model_24h_RF_fast.joblib",
    "LR_48h": "model_48h_LR.joblib",
    "RF_48h": "model_48h_RF_fast.joblib",
}


@st.cache_resource
def load_models():
    """Load all models with caching"""
    models = {}
    for model, file in MODEL_MAP.items():
        try:
            model_path = os.path.join(MODELS_DIR, file)
            models[model] = joblib.load(model_path)
        except FileNotFoundError:
            st.error(f"Model file {file} not found in {MODELS_DIR}")
            return None
    return models


@st.cache_resource
def load_explainers(_models):
    """Load SHAP explainers for each model"""
    explainers = {}
    
    try:
        telemetry = pd.read_csv("data/processed/telemetry.csv", parse_dates=["datetime"])
        
        exclude_cols = {"datetime", "machineID", "will_fail_in_24h", "will_fail_in_48h"}
        features_cols = [c for c in telemetry.columns if c not in exclude_cols]
        X_sample = telemetry[features_cols].head(1000)
        
        progress_text = "Loading explainers for all models..."
        progress_bar = st.progress(0, text=progress_text)
        
        for idx, (model_name, model) in enumerate(_models.items()):
            progress_bar.progress((idx + 1) / len(_models), 
                                 text=f"Loading {model_name} explainer...")
            model_type = 'tree' if 'RF' in model_name else 'linear'
            explainer = ModelExplainer(model, model_type=model_type)
            explainer.fit(X_sample)
            explainers[model_name] = explainer
        
        progress_bar.empty()
        return explainers
    except Exception as e:
        st.warning(f"Could not load explainers: {e}")
        return None


def render_prediction_tab(models, selected_model, threshold):
    """Render the main prediction tab"""
    st.header("Machine Failure Prediction")
    
    input_method = st.radio(
        "Data Input Method:",
        ["Upload CSV File", "Use Sample Data", "Manual Input"],
        horizontal=True
    )
    
    df_input = None
    
    # Handle different input methods
    if input_method == "Upload CSV File":
        df_input = handle_file_upload()
    elif input_method == "Use Sample Data":
        df_input = create_sample_data()
        st.info("Using sample data for demonstration")
    elif input_method == "Manual Input":
        df_input = handle_manual_input()
    
    # Store in session state
    if df_input is not None:
        st.session_state.df_input = df_input
    
    # Process predictions if data is available
    if df_input is not None:
        st.subheader("Input Data Preview")
        st.dataframe(df_input.head())
        
        if st.button("🔮 Make Predictions", type="primary"):
            make_predictions(df_input, models, selected_model, threshold)
    
    # Display previous results if they exist
    if 'prediction_done' in st.session_state and st.session_state.prediction_done:
        # Show results section
        st.subheader("🎯 Prediction Results")
        display_prediction_results(st.session_state.results_df, threshold)
        
        # Show explanation section
        generate_explanation(st.session_state.results_df, models, selected_model, st.session_state.predictions_proba, threshold)


def handle_file_upload():
    """Handle CSV file upload"""
    uploaded_file = st.file_uploader(
        "Choose a CSV file",
        type="csv",
        help="Upload telemetry data with columns: machineID, datetime, volt, rotate, pressure, vibration"
    )
    
    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            st.success(f"File uploaded successfully! {len(df)} rows loaded.")
            return df
        except Exception as e:
            st.error(f"Error reading file: {e}")
    return None


def handle_manual_input():
    """Handle manual data entry"""
    st.subheader("Enter Machine Data")
    col1, col2 = st.columns(2)

    with col1:
        machine_id = st.number_input("Machine ID", min_value=1, value=1)
        volt = st.number_input("Voltage", min_value=0.0, value=170.0)
        rotate = st.number_input("Rotation", min_value=0.0, value=420.0)

    with col2:
        pressure = st.number_input("Pressure", min_value=0.0, value=100.0)
        vibration = st.number_input("Vibration", min_value=0.0, value=40.0)
        model_type = st.selectbox("Model", ["model1", "model2", "model3", "model4"])

    df = pd.DataFrame({
        'machineID': [machine_id],
        'datetime': ['2015-12-01 10:00:00'],
        'volt': [volt],
        'rotate': [rotate],
        'pressure': [pressure],
        'vibration': [vibration],
        'model': [model_type],
        'age': [10]
    })

    st.write("Current Input Data:")
    st.dataframe(df)
    return df


def make_predictions(df_input, models, selected_model, threshold):
    """Process data and make predictions"""
    try:
        with st.spinner("Processing data and making predictions..."):
            model = models[selected_model]
            
            # Process each row separately
            all_predictions = []
            for idx in range(len(df_input)):
                single_row = df_input.iloc[[idx]]
                processed_single = process_telemetry(single_row)
                pred_proba = model.predict_proba(processed_single)[0, 1]
                all_predictions.append(pred_proba)
            
            predictions_proba = np.array(all_predictions)
            predictions_binary = (predictions_proba >= threshold).astype(int)
            
            results_df = df_input.copy()
            results_df['failure_probability'] = predictions_proba
            results_df['failure_prediction'] = predictions_binary
            results_df['risk_level'] = pd.cut(
                predictions_proba, 
                bins=[0, 0.3, 0.7, 1.0], 
                labels=['Low', 'Medium', 'High']
            )
        
        # Save results to session state
        st.session_state.results_df = results_df
        st.session_state.predictions_proba = predictions_proba
        st.session_state.prediction_done = True
        st.session_state.last_prediction_time = time.time()
        
        # Clear any previous explanation
        keys_to_clear = ['current_explanation', 'current_explainer', 'current_machine_id', 
                        'explain_requested', 'explained_machine_id']
        for key in keys_to_clear:
            if key in st.session_state:
                del st.session_state[key]
        
        # Success message
        st.success("✅ Predictions completed!")
        
    except Exception as e:
        st.error(f"Prediction error: {e}")


def display_prediction_results(results_df, threshold):
    """Display prediction results and visualizations"""
    # Don't show header here, it's shown in render_prediction_tab
    
    # Metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Machines", len(results_df))
    with col2:
        high_risk = (results_df['failure_probability'] >= threshold).sum()
        st.metric("High Risk Machines", high_risk)
    with col3:
        avg_risk = results_df['failure_probability'].mean()
        st.metric("Average Risk", f"{avg_risk:.3f}")
    with col4:
        max_risk = results_df['failure_probability'].max()
        st.metric("Maximum Risk", f"{max_risk:.3f}")
    
    # Risk distribution histogram
    if len(results_df) > 1:
        fig = px.histogram(
            results_df, 
            x='failure_probability', 
            title="Risk Distribution",
            nbins=20
        )
        fig.add_vline(
            x=threshold, 
            line_dash="dash", 
            line_color="red", 
            annotation_text="Threshold"
        )
        # Always use unique key with timestamp
        st.plotly_chart(fig, use_container_width=True, key=f"risk_hist_{int(time.time() * 1000000)}")
    
    # Detailed results table
    st.subheader("Detailed Results")
    display_results_table(results_df)
    
    # Download button
    csv = results_df.to_csv(index=False)
    st.download_button(
        "📥 Download Results",
        csv,
        "prediction_results.csv",
        "text/csv"
    )


def display_results_table(results_df):
    """Format and display results table"""
    base_cols = ['machineID', 'model', 'failure_probability', 'failure_prediction', 'risk_level']
    display_cols = []
    
    if 'datetime' in results_df.columns:
        display_cols.append('datetime')
    
    for col in base_cols:
        if col not in display_cols:
            display_cols.append(col)

    available_cols = [col for col in display_cols if col in results_df.columns]
    display_df = results_df[available_cols].copy()
    
    if 'failure_prediction' in display_df.columns:
        display_df['Status'] = display_df['failure_prediction'].map({
            0: '✅ Normal', 
            1: '⚠ High Risk'
        })
    
    if 'failure_probability' in display_df.columns:
        display_df['failure_probability'] = display_df['failure_probability'].round(4)

    st.dataframe(display_df, use_container_width=True)


def generate_explanation(results_df, models, selected_model, predictions_proba, threshold):
    """Generate SHAP explanation for predictions"""
    st.markdown("---")
    st.header("🔍 Explain This Prediction")
    
    # Write label separately
    st.write("**Select Machine to Explain:**")
    
    # Select which machine to explain - using columns for alignment
    col_select, col_explain_btn, col_clear_btn = st.columns([5, 1, 1])
    
    with col_select:
        if len(results_df) > 1:
            machine_options = results_df['machineID'].tolist()
            selected_machine_idx = st.selectbox(
                "Select Machine to Explain:",
                range(len(machine_options)),
                format_func=lambda x: f"Machine {machine_options[x]} - Risk: {predictions_proba[x]:.1%}",
                key="machine_selector",
                label_visibility="collapsed"  # Hide the label inside selectbox
            )
        else:
            selected_machine_idx = 0
            st.info(f"Machine {results_df.iloc[0]['machineID']} - Risk: {predictions_proba[0]:.1%}")
    
    with col_explain_btn:
        explain_button = st.button("🔍 Explain", type="primary", use_container_width=True)
    
    with col_clear_btn:
        clear_button = st.button("🗑️ Clear", use_container_width=True)
    
    # Handle clear button
    if clear_button:
        # Clear all explanation-related session state
        keys_to_clear = ['current_explanation', 'current_explainer', 'current_machine_id', 
                        'explain_requested', 'explained_machine_id']
        for key in keys_to_clear:
            if key in st.session_state:
                del st.session_state[key]
        st.rerun()  # Force rerun to clear display
    
    # Get selected machine info
    selected_machine_id = results_df.iloc[selected_machine_idx]['machineID']
    selected_prediction = predictions_proba[selected_machine_idx]
    
    # Store machine info for display
    machine_info = {
        'machineID': selected_machine_id,
        'datetime': results_df.iloc[selected_machine_idx].get('datetime', 'N/A'),
        'model': results_df.iloc[selected_machine_idx].get('model', 'N/A')
    }
    
    # Check if machine changed - if yes, clear the cache
    if 'current_machine_id' in st.session_state:
        if st.session_state.current_machine_id != selected_machine_id:
            # Machine changed, clear explanation cache
            if 'current_explanation' in st.session_state:
                del st.session_state.current_explanation
            if 'current_explainer' in st.session_state:
                del st.session_state.current_explainer
            st.session_state.current_machine_id = None
            st.session_state.explain_requested = False
    
    # Check if we should display explanation
    should_display = False
    
    # If button clicked, generate new explanation
    if explain_button:
        st.session_state.explain_requested = True
        st.session_state.explained_machine_id = selected_machine_id
        should_display = True
    
    # If explanation exists for this machine, display it
    elif ('explain_requested' in st.session_state and 
          st.session_state.explain_requested and
          'explained_machine_id' in st.session_state and
          st.session_state.explained_machine_id == selected_machine_id):
        should_display = True
    
    # If we're displaying explanation for same machine and it's cached
    if should_display and ('current_explanation' in st.session_state and 
        'current_explainer' in st.session_state and
        'current_machine_id' in st.session_state and
        st.session_state.current_machine_id == selected_machine_id):
        display_explanation(st.session_state.current_explanation, 
                          st.session_state.current_explainer,
                          machine_info)
        return
    
    # If should display but not cached, generate new
    if should_display:
        try:
            # Get the actual input row for this machine
            machine_input_row = results_df.iloc[[selected_machine_idx]].copy()
            
            # Process the actual row to get features
            with st.spinner("Processing machine data..."):
                processed_row = process_telemetry(machine_input_row)
            
            with st.spinner("🔧 Loading explainer models... (This may take 30-60 seconds on first run)"):
                explainers = load_explainers(models)
            
            if explainers is not None:
                explainer = explainers[selected_model]
                
                X_transformed = explainer.model.named_steps['prep'].transform(processed_row)
                
                with st.spinner("Generating explanation..."):
                    shap_values = explainer.explainer.shap_values(X_transformed)
                    
                    if isinstance(shap_values, list):
                        shap_values = shap_values[1]
                    
                    if hasattr(explainer.explainer, 'expected_value'):
                        base_value = explainer.explainer.expected_value
                        if isinstance(base_value, np.ndarray):
                            base_value = base_value[1] if len(base_value) > 1 else base_value[0]
                    else:
                        base_value = 0.5
                    
                    feature_names = explainer.model.named_steps['prep'].get_feature_names_out()
                    feature_impacts = pd.DataFrame({
                        'feature': feature_names,
                        'value': X_transformed[0],
                        'impact': shap_values[0]
                    })
                    feature_impacts = feature_impacts.sort_values('impact', key=abs, ascending=False)
                    
                    explanation = {
                        'prediction': 1 if selected_prediction >= threshold else 0,
                        'probability': selected_prediction,
                        'base_value': base_value,
                        'shap_values': shap_values[0],
                        'feature_impacts': feature_impacts,
                        'feature_names': feature_names
                    }
                
                # Save to session state including machine ID
                st.session_state.current_explanation = explanation
                st.session_state.current_explainer = explainer
                st.session_state.current_machine_id = selected_machine_id
                
                display_explanation(explanation, explainer, machine_info)
                
        except Exception as e:
            st.warning(f"Could not generate explanation: {str(e)}")
            st.info("Explanation works best with processed training data")
    else:
        st.info("👆 Select a machine and click 'Explain' to see the detailed analysis")


def display_explanation(explanation, explainer, machine_info):
    """Display explanation results with auto-calculated feature count for 90% cumulative impact"""
    if explanation is None or explainer is None:
        st.error("Missing explanation data")
        return
    
    st.success("Explanation Generated")
    
    # Display Machine Information prominently
    st.subheader(f"🔧 Machine {machine_info['machineID']} Analysis")
    info_col1, info_col2, info_col3 = st.columns(3)
    with info_col1:
        st.info(f"**Machine ID:** {machine_info['machineID']}")
    with info_col2:
        st.info(f"**Timestamp:** {machine_info['datetime']}")
    with info_col3:
        st.info(f"**Model:** {machine_info['model']}")
    
    st.markdown("---")
    
    # Metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric(
            "Prediction",
            "FAILURE" if explanation['prediction'] == 1 else "NORMAL"
        )
    with col2:
        st.metric(
            "Failure Probability",
            f"{explanation['probability']:.1%}"
        )
    with col3:
        risk = "HIGH" if explanation['probability'] > 0.7 else "MEDIUM" if explanation['probability'] > 0.3 else "LOW"
        st.metric("Risk Level", risk)
    
    # Calculate features needed for 90% cumulative impact
    impacts_df = explanation['feature_impacts'].copy()
    impacts_df['abs_impact'] = impacts_df['impact'].abs()
    impacts_df = impacts_df.sort_values('abs_impact', ascending=False)
    
    total_impact = impacts_df['abs_impact'].sum()
    impacts_df['cumulative_impact'] = impacts_df['abs_impact'].cumsum()
    impacts_df['cumulative_pct'] = (impacts_df['cumulative_impact'] / total_impact) * 100
    
    # Find number of features for 90% threshold
    features_for_90 = (impacts_df['cumulative_pct'] <= 90).sum()
    # Ensure at least 5 features, max 20
    num_features = max(5, min(features_for_90, 20))
    
    # Waterfall plot
    st.subheader("Feature Contribution Waterfall")
    actual_pct = impacts_df.iloc[num_features-1]['cumulative_pct'] if num_features > 0 else 0
    st.markdown(f"*Showing top {num_features} features representing ~{actual_pct:.1f}% of total impact*")
    st.markdown("*Red = Increases risk | Green = Decreases risk*")
    
    fig_waterfall = explainer.plot_waterfall(explanation, num_features)
    # Use timestamp to ensure unique key
    st.plotly_chart(fig_waterfall, use_container_width=True, key=f"waterfall_{machine_info['machineID']}_{int(time.time() * 1000000)}")
    
    # Feature impacts table
    st.subheader("Top Feature Impacts")
    
    display_impacts = impacts_df.head(15).copy()
    display_impacts['impact'] = display_impacts['impact'].round(4)
    display_impacts['value'] = display_impacts['value'].round(2)
    display_impacts['cumulative_pct'] = display_impacts['cumulative_pct'].round(1)
    display_impacts['effect'] = display_impacts['impact'].apply(
        lambda x: "Increases Risk" if x > 0 else "Decreases Risk"
    )
    
    st.dataframe(
        display_impacts[['feature', 'value', 'impact', 'cumulative_pct', 'effect']].rename(
            columns={'cumulative_pct': 'Cumulative %'}
        ),
        use_container_width=True,
        hide_index=True
    )
    
    # Summary recommendation
    display_recommendation(explanation, machine_info)


def display_recommendation(explanation, machine_info):
    """Display recommendation based on prediction"""
    top_feature = explanation['feature_impacts'].iloc[0]
    
    if explanation['prediction'] == 1:
        st.error(f"""
        **High Failure Risk Detected for Machine {machine_info['machineID']}**
        
        Main driver: **{top_feature['feature']}** (impact: {top_feature['impact']:.3f})
        
        **Recommended Actions:**
        - Schedule immediate inspection for Machine {machine_info['machineID']}
        - Monitor {top_feature['feature']} closely
        - Review maintenance logs for this machine
        """)
    else:
        st.success(f"""
        **Machine {machine_info['machineID']} Operating Normally**
        
        All indicators within acceptable ranges.
        
        **Continue monitoring:** {top_feature['feature']} (value: {top_feature['value']:.2f})
        """)


def render_about_tab():
    """Render the about/info tab"""
    st.header("ℹ️ About This System")
    st.markdown("""
    ### Predictive Maintenance System with Explainability
    
    This system uses machine learning to predict equipment failures before they occur,
    and explains WHY each prediction is made.
    
    **Models Available:**
    - **LR_24h**: Logistic Regression for 24-hour prediction
    - **RF_24h**: Random Forest for 24-hour prediction  
    - **LR_48h**: Logistic Regression for 48-hour prediction
    - **RF_48h**: Random Forest for 48-hour prediction
    
    **Features:**
    - 🔍 **Explainability (XAI)**: Understand which features drive each prediction
    - 🌊 **Waterfall Charts**: Visual breakdown of feature contributions
    - 📊 **Feature Impact Analysis**: See how each sensor affects the prediction
    
    **Input Data Required:**
    - `machineID`: Unique identifier for each machine
    - `datetime`: Timestamp of the measurement
    - `volt`: Voltage reading
    - `rotate`: Rotation speed
    - `pressure`: Pressure measurement  
    - `vibration`: Vibration level
    - `model`: Machine model (optional, will default to model1)
    - `age`: Machine age in years (optional, will default to 18)
    
    **How it works:**
    1. Upload your telemetry data
    2. The system engineers features from the raw sensor data
    3. Machine learning models predict failure probability
    4. SHAP explainer shows which features contributed most
    5. Get actionable insights on which machines need attention
    
    **Technology Stack:**
    - 🤖 **ML**: Scikit-learn (Random Forest, Logistic Regression)
    - 🔍 **XAI**: SHAP (SHapley Additive exPlanations)
    - 📊 **Frontend**: Streamlit + Plotly
    """)


def render_sample_data_tab():
    """Render the sample data tab"""
    st.header("🔧 Sample Data")
    st.write("Here's a sample of the expected data format:")
    sample_df = create_sample_data()
    st.dataframe(sample_df)
    
    csv_sample = sample_df.to_csv(index=False)
    st.download_button(
        "📥 Download Sample CSV",
        csv_sample,
        "sample_telemetry.csv",
        "text/csv",
        help="Download this sample to test the application"
    )


def main():
    """Main application entry point"""
    st.title("⚙️ Predictive Maintenance System")
    #apply_premium_theme()
    st.markdown("---")

    # Load models
    models = load_models()
    if models is None:
        st.error("Failed to load models. Please ensure model files exist.")
        return

    # Sidebar configuration
    st.sidebar.header("Configuration")
    
    selected_model = st.sidebar.selectbox(
        "Select Model",
        list(MODEL_MAP.keys()),
        help="Choose prediction horizon and algorithm"
    )
    
    threshold = st.sidebar.slider(
        "Prediction Threshold",
        min_value=0.0,
        max_value=1.0,
        value=0.5,
        step=0.01,
        help="Threshold for failure prediction (higher = more conservative)"
    )
    st.session_state.current_threshold = threshold
    # Create tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "📊 Prediction", 
        "📈 Data Analysis", 
        "🔧 Sample Data", 
        "ℹ️ About"
    ])
    
    # Store df_input in session state for sharing between tabs
    if 'df_input' not in st.session_state:
        st.session_state.df_input = None
    
    with tab1:
        render_prediction_tab(models, selected_model, threshold)
    
    with tab2:
        render_analysis_tab(st.session_state.df_input)
    
    with tab3:
        render_sample_data_tab()
    
    with tab4:
        render_about_tab()


if __name__ == "__main__":
    main()