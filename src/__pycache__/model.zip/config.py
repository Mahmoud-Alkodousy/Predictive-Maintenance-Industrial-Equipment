import os
from pathlib import Path

# ===== Auto-detect project root =====
def find_project_root():

    current = Path(__file__).parent.absolute()
    
    # جرب المجلد الحالي الأول
    if (current / "data" / "models").exists():
        return current
    
    # جرب المجلد الأب
    parent = current.parent
    if (parent / "data" / "models").exists():
        return parent
    
    # جرب جد المجلد (لو احنا في src/)
    grandparent = parent.parent
    if (grandparent / "data" / "models").exists():
        return grandparent
    
    # لو مش لاقي، استخدم المجلد الحالي
    print(f"⚠️ Warning: Could not find data/models directory. Using: {current}")
    return current

PROJECT_ROOT = find_project_root()
print(f"✅ Project root detected: {PROJECT_ROOT}")

# ===== Directory Structure =====
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = DATA_DIR / "models"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
GRAPHS_DIR = DATA_DIR / "graphs"

# ===== Create directories if not exist =====
for directory in [DATA_DIR, MODELS_DIR, RAW_DATA_DIR, PROCESSED_DATA_DIR, GRAPHS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)
    print(f"📁 {directory.name}: {directory.exists()}")

# ===== Model Files =====
MODEL_FILES = {
    "LR_24h": MODELS_DIR / "model_24h_LR.joblib",
    "RF_24h": MODELS_DIR / "model_24h_RF_fast.joblib",
    "LR_48h": MODELS_DIR / "model_48h_LR.joblib",
    "RF_48h": MODELS_DIR / "model_48h_RF_fast.joblib",
}

# ===== Check which models exist =====
print("\n🔍 Checking model files:")
for name, path in MODEL_FILES.items():
    exists = path.exists()
    status = "✅" if exists else "❌"
    print(f"{status} {name}: {path}")

# ===== Image Inspection Models =====
VGG_MODEL_PATH = MODELS_DIR / "industrial_defect_detection_model.h5"
YOLO_WEIGHTS_PATH = MODELS_DIR / "yolo_best.pt"
YOLOV5_DIR = PROJECT_ROOT / "yolov5"

print(f"\n🖼️ Image models:")
print(f"{'✅' if VGG_MODEL_PATH.exists() else '❌'} VGG16: {VGG_MODEL_PATH}")
print(f"{'✅' if YOLO_WEIGHTS_PATH.exists() else '❌'} YOLO: {YOLO_WEIGHTS_PATH}")
print(f"{'✅' if YOLOV5_DIR.exists() else '❌'} YOLOv5 dir: {YOLOV5_DIR}")

# ===== Model Settings =====
DEFAULT_THRESHOLD = 0.5
RANDOM_STATE = 42

# ===== Feature Engineering Parameters =====
SENSORS = ["volt", "rotate", "pressure", "vibration"]
LAGS = [1, 3, 6, 12, 24]
ROLL_MEANS = [3, 6, 12, 24, 48]
ROLL_STDS = [6, 24, 48]
SLOPES_K = [3, 6, 12]

# ===== Helper function to get available models =====
def get_available_models():

    return {name: path for name, path in MODEL_FILES.items() if path.exists()}

# Print summary
available = get_available_models()
print(f"\n📊 Summary: {len(available)}/{len(MODEL_FILES)} models available")

if len(available) == 0:
    print("\n⚠️ WARNING: No model files found!")
    print(f"Expected location: {MODELS_DIR}")
    print("\nPlease ensure model files are in the correct location.")