"""
Data Preprocessing Script
Creates features and targets for model training
Run after data_acquisition.py
"""

import matplotlib.pyplot as plt
from tqdm import tqdm
from data_acquisition import load_data
from config import SENSORS, LAGS, ROLL_MEANS, ROLL_STDS, SLOPES_K, RAW_DATA_DIR, PROCESSED_DATA_DIR, GRAPHS_DIR
from functions import (
    check_future_failure,
    add_error_flags_per_machine,
    add_time_since_maint,
    add_sensor_features,
)

def process_telemetry(telemetry, failures, machines, errors, maintenance):
    """Complete telemetry processing pipeline"""
    
    # Initialize target variables
    telemetry["will_fail_in_24h"] = 0
    telemetry["will_fail_in_48h"] = 0

    # Group failures by machine
    failures_by_machine = failures.groupby("machineID")["datetime"].apply(list).to_dict()

    # Assign 24h target
    tqdm.pandas(desc="Assign 24h target variable")
    telemetry["will_fail_in_24h"] = telemetry.progress_apply(
        lambda row: check_future_failure(
            row["datetime"], failures_by_machine.get(row["machineID"], []), 24
        ),
        axis=1,
    ).astype("int8")

    # Assign 48h target
    tqdm.pandas(desc="Assign 48h target variable")
    telemetry["will_fail_in_48h"] = telemetry.progress_apply(
        lambda row: check_future_failure(
            row["datetime"], failures_by_machine.get(row["machineID"], []), 48
        ),
        axis=1,
    ).astype("int8")

    print("\nGenerated targets:")
    print(telemetry[["will_fail_in_24h", "will_fail_in_48h"]].sum())

    # Merge machine info
    telemetry = telemetry.merge(machines, on="machineID", how="left")
    telemetry = telemetry.sort_values(["machineID", "datetime"]).reset_index(drop=True)

    # Add error flags
    error_types = errors["errorID"].unique().tolist()
    for et in error_types:
        telemetry = add_error_flags_per_machine(telemetry, errors, et)

    print("\nErrors within time window:")
    print(telemetry[[c for c in telemetry.columns if "error" in c]].sum().sort_index())

    # Add maintenance features
    maintenance = maintenance.sort_values(["machineID", "datetime"]).reset_index(drop=True)
    components = maintenance["comp"].unique().tolist()
    for comp in components:
        telemetry = add_time_since_maint(telemetry, maintenance, comp)

    maint_cols = [c for c in telemetry.columns if c.startswith("time_since_maint_")]
    print("\nMaintenance columns generated:", len(maint_cols))

    # Add sensor features
    telemetry = add_sensor_features(
        telemetry, SENSORS, LAGS, ROLL_MEANS, ROLL_STDS, SLOPES_K
    )

    feature_cols = [
        c for c in telemetry.columns
        if any(s in c for s in ["_lag_", "_mean_", "_std_", "_slope_"])
    ]
    print("\nTotal sensor features:", len(feature_cols))

    return telemetry


def main():
    """Main preprocessing pipeline"""
    
    # Load raw data
    telemetry, errors, maintenance, failures, machines = load_data()

    # Process telemetry
    telemetry = process_telemetry(telemetry, failures, machines, errors, maintenance)

    # Save processed data
    telemetry.to_csv(PROCESSED_DATA_DIR / "telemetry.csv", index=False)

    # Print summary
    print("\n===== Preprocessing Summary =====")
    print(f"Total rows: {len(telemetry):,}")
    print(f"Total columns: {len(telemetry.columns)}")
    print("\nClass balance 24h:")
    print(telemetry["will_fail_in_24h"].value_counts(normalize=True))
    print("\nClass balance 48h:")
    print(telemetry["will_fail_in_48h"].value_counts(normalize=True))

    # Create visualizations
    telemetry[SENSORS].hist(bins=50, figsize=(10, 6))
    plt.suptitle("Sensor Distribution")
    plt.savefig(GRAPHS_DIR / "sensor_distribution.png")
    plt.close()

    for target in ["will_fail_in_24h", "will_fail_in_48h"]:
        plt.figure(figsize=(12, 4))
        telemetry.groupby("datetime")[target].mean().plot()
        plt.title(f"Proportion of positive failures ({target})")
        plt.ylabel("Proportion")
        plt.savefig(f"data/graphs/{target}_positive_failures.png")
        plt.close()


if __name__ == "__main__":
    main()
