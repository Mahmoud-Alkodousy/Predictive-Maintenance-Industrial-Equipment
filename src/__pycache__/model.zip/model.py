"""
Model Training Script
Trains and evaluates models for 24h and 48h horizons
Run after data_preprocessing.py
"""

import os
import random
import pandas as pd
import numpy as np
import joblib
from pathlib import Path
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, OrdinalEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.base import BaseEstimator, TransformerMixin
from config import RANDOM_STATE, MODELS_DIR, PROCESSED_DATA_DIR
from functions import (
    build_split, best_threshold_by_fbeta, metrics_block, 
    plot_roc, print_confmat, RANDOM_STATE
)

# Set seed
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
os.environ["PYTHONHASHSEED"] = str(SEED)


# Custom transformer
class ToFloat32(BaseEstimator, TransformerMixin):
    """Cast to float32 for memory efficiency"""
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        return X.astype(np.float32)


def build_preprocessor_lr(X_sample):
    """Preprocessor for Logistic Regression"""
    cat_features = [c for c in ["model"] if c in X_sample.columns]
    num_features = [c for c in X_sample.columns if c not in cat_features]
    return ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat_features)
            if cat_features else ("cat", "drop", []),
            ("num", Pipeline([
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler(with_mean=False)),
            ]), num_features),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )


def build_preprocessor_rf(X_sample):
    """Preprocessor for Random Forest"""
    cat_features = [c for c in ["model"] if c in X_sample.columns]
    num_features = [c for c in X_sample.columns if c not in cat_features]
    return ColumnTransformer(
        transformers=[
            ("cat", Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("ord", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)),
            ]), cat_features) if cat_features else ("cat", "drop", []),
            ("num", SimpleImputer(strategy="median"), num_features),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )


def make_lr(X_sample):
    """Build Logistic Regression pipeline"""
    return Pipeline([
        ("prep", build_preprocessor_lr(X_sample)),
        ("clf", LogisticRegression(
            penalty="l2", C=1.0, solver="liblinear",
            class_weight="balanced", max_iter=1000,
            random_state=RANDOM_STATE
        )),
    ])


def make_rf_fast(X_sample):
    """Build Random Forest pipeline"""
    return Pipeline([
        ("prep", build_preprocessor_rf(X_sample)),
        ("to32", ToFloat32()),
        ("clf", RandomForestClassifier(
            n_estimators=200, max_depth=16, min_samples_leaf=5,
            max_features="sqrt", bootstrap=True, max_samples=0.7,
            class_weight="balanced_subsample", n_jobs=-1,
            random_state=RANDOM_STATE
        )),
    ])


def evaluate_and_save_models(splits, label, save_dir="data/models"):
    """Train, evaluate and save models for a time horizon"""
    X_train, y_train = splits[f"X_train_{label}"], splits[f"y_train_{label}"]
    X_val, y_val = splits[f"X_val_{label}"], splits[f"y_val_{label}"]
    X_test, y_test = splits[f"X_test_{label}"], splits[f"y_test_{label}"]

    Path(save_dir).mkdir(parents=True, exist_ok=True)

    specs = [("LR", make_lr), ("RF_fast", make_rf_fast)]
    rows, models_out = [], {}

    for name, maker in specs:
        print(f"\n===== Training {label} :: {name} =====")
        
        # Train
        pipe = maker(X_train)
        pipe.fit(X_train, y_train)

        # Save
        model_path = Path(save_dir) / f"model_{label}_{name}.joblib"
        joblib.dump(pipe, model_path)
        print(f"✅ Saved: {model_path}")

        # Predictions
        val_prob = pipe.predict_proba(X_val)[:, 1]
        test_prob = pipe.predict_proba(X_test)[:, 1]

        # Find optimal threshold
        thr, f2_val = best_threshold_by_fbeta(y_val.values, val_prob, beta=2.0)
        print(f"Optimal threshold (F2): {thr:.3f} | F2(val): {f2_val:.4f}")

        # Print confusion matrices
        print_confmat(y_val, val_prob, thr, f"[VAL] {label}-{name}")
        print_confmat(y_test, test_prob, thr, f"[TEST] {label}-{name}")

        # Plot ROC curves
        plot_roc(y_val, val_prob, f"ROC (VAL) - {label} {name}")
        plot_roc(y_test, test_prob, f"ROC (TEST) - {label} {name}")

        # Collect metrics
        m_val = metrics_block(y_val.values, val_prob, thr)
        m_test = metrics_block(y_test.values, test_prob, thr)
        rows.append({"horizon": label, "model": name, "split": "VAL", "threshold": thr, **m_val})
        rows.append({"horizon": label, "model": name, "split": "TEST", "threshold": thr, **m_test})

        models_out[(label, name)] = pipe

    return pd.DataFrame(rows), models_out


def main():
    """Main training pipeline"""
    
    # Load processed data
    telemetry = pd.read_csv(PROCESSED_DATA_DIR / "telemetry.csv", parse_dates=["datetime"])
    telemetry["model"] = telemetry["model"].astype("category")

    # Prepare features
    exclude_cols = {"datetime", "machineID", "will_fail_in_24h", "will_fail_in_48h"}
    features_cols = [c for c in telemetry.columns if c not in exclude_cols]

    X = telemetry[features_cols]
    y_24 = telemetry["will_fail_in_24h"].astype(int)
    y_48 = telemetry["will_fail_in_48h"].astype(int)

    # Create splits
    cut_train = pd.Timestamp("2015-09-30 23:59:59")
    cut_val = pd.Timestamp("2015-11-15 23:59:59")
    train_mask = telemetry["datetime"] <= cut_train
    val_mask = (telemetry["datetime"] > cut_train) & (telemetry["datetime"] <= cut_val)
    test_mask = telemetry["datetime"] > cut_val

    splits_24 = build_split(X, y_24, train_mask, val_mask, test_mask, "24h", telemetry["datetime"])
    splits_48 = build_split(X, y_48, train_mask, val_mask, test_mask, "48h", telemetry["datetime"])

    # Train models
    df24, models24 = evaluate_and_save_models(splits_24, "24h")
    df48, models48 = evaluate_and_save_models(splits_48, "48h")

    # Save metrics summary
    eval_all = pd.concat([df24, df48], ignore_index=True)
    eval_all.to_csv(MODELS_DIR / "eval_summary.csv", index=False)
    
    print("\n===== Training Complete =====")
    print(eval_all[["horizon", "model", "split", "f2", "roc_auc", "recall"]])


if __name__ == "__main__":
    main()
