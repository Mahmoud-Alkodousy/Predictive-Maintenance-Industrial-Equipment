"""
Explainability Module - SHAP-based model interpretability
"""

import shap
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import warnings
warnings.filterwarnings('ignore')


class ModelExplainer:
    """Wrapper class for model explainability using SHAP"""
    
    def __init__(self, model, model_type: str = 'tree'):
        """
        Initialize explainer
        Args:
            model: Trained model (sklearn pipeline)
            model_type: 'tree' for RF, 'linear' for LR
        """
        self.model = model
        self.model_type = model_type
        self.explainer = None
        self.feature_names = None
        
    def fit(self, X_train: pd.DataFrame):
        """Fit the explainer on training data"""
        print(f"🔧 Fitting {self.model_type} explainer...")
        
        X_transformed = self.model.named_steps['prep'].transform(X_train)
        self.feature_names = self.model.named_steps['prep'].get_feature_names_out()
        
        actual_model = self.model.named_steps['clf']
        
        if self.model_type == 'tree':
            self.explainer = shap.TreeExplainer(actual_model)
        elif self.model_type == 'linear':
            self.explainer = shap.LinearExplainer(actual_model, X_transformed)
        
        print(f"✅ Explainer fitted successfully")
    
    def plot_waterfall(self, explanation: dict, max_features: int = 10) -> go.Figure:
        """Create waterfall plot showing feature contributions"""
        impacts = explanation['feature_impacts'].head(max_features)
        
        features = impacts['feature'].tolist()
        values = impacts['impact'].tolist()
        
        fig = go.Figure(go.Waterfall(
            orientation="h",
            measure=["relative"] * len(values),
            y=features[::-1],
            x=values[::-1],
            connector={"line": {"color": "rgb(63, 63, 63)"}},
            increasing={"marker": {"color": "red"}},
            decreasing={"marker": {"color": "green"}},
        ))
        
        fig.update_layout(
            title=f"🔍 Top {max_features} Feature Contributions<br>"
                  f"Prediction: {explanation['probability']:.1%} failure probability",
            xaxis_title="Impact on Prediction",
            yaxis_title="Feature",
            height=400 + (max_features * 20),
            showlegend=False
        )
        
        return fig
