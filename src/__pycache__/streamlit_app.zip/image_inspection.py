"""
Image Inspection Module - VGG16 + YOLOv5
Detects if defected and locates defect position
FIXED VERSION - Using subprocess to match training exactly
"""

import streamlit as st
import cv2
import numpy as np
from PIL import Image
import tensorflow as tf
from pathlib import Path
import tempfile
import os
import subprocess
import shutil


@st.cache_resource
def load_vgg_model():
    """Load VGG16 model"""
    try:
        model_path = r"E:\Temp_Projects\Depi-Predictive-Maintenance-Project\data\models\industrial_defect_detection_model.h5"
        
        model = tf.keras.models.load_model(model_path, compile=False)
        
        model.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        return model
        
    except Exception as e:
        st.error(f"❌ Failed to load VGG16 model: {e}")
        return None


def check_yolo_setup():
    """Check if YOLO is properly set up"""
    yolov5_path = r"E:\Temp_Projects\Depi-Predictive-Maintenance-Project\yolov5"
    weights_path = r"E:\Temp_Projects\Depi-Predictive-Maintenance-Project\data\models\yolo_best.pt"
    detect_script = os.path.join(yolov5_path, "detect.py")
    
    yolo_exists = os.path.exists(yolov5_path)
    weights_exists = os.path.exists(weights_path)
    detect_exists = os.path.exists(detect_script)
    
    return {
        'ready': yolo_exists and weights_exists and detect_exists,
        'yolov5_path': yolov5_path,
        'weights_path': weights_path,
        'detect_script': detect_script,
        'yolo_exists': yolo_exists,
        'weights_exists': weights_exists,
        'detect_exists': detect_exists
    }


def classify_defect(vgg_model, image, threshold=0.5):
    """Classify image as Defected or Non-Defected using VGG16"""
    # Resize to 224x224
    img = image.resize((224, 224))
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    
    # Predict
    pred = vgg_model.predict(img_array, verbose=0)
    prob = float(pred[0][0])
    
    # prob >= 0.5 → Non-Defected
    if prob >= threshold:
        label = 'Non-Defected'
        confidence = prob
    else:
        label = 'Defected'
        confidence = 1 - prob
    
    return {
        'label': label,
        'confidence': confidence,
        'probability': prob,
        'is_defected': label == 'Defected'
    }


def locate_defect_yolo_subprocess(image, yolo_config):
    """
    Locate defects using YOLOv5 via subprocess (EXACT method from training)
    
    Args:
        image: PIL Image
        yolo_config: Dictionary with YOLO paths
    
    Returns:
        dict with detection results
    """
    
    # Create temporary directory for this detection
    temp_dir = tempfile.mkdtemp()
    temp_image_path = os.path.join(temp_dir, "temp_image.jpg")
    
    try:
        # Save image temporarily
        image.save(temp_image_path)
        
        st.write(f"🔍 **YOLO Detection Settings:**")
        st.write(f"- Image size: 416")
        st.write(f"- Confidence threshold: 0.1")
        st.write(f"- IoU threshold: 0.45")
        st.write(f"- Using detect.py file")
        
        # CRITICAL: Use subprocess to run detect.py EXACTLY like training
        cmd = [
            'python',
            yolo_config['detect_script'],
            '--weights', yolo_config['weights_path'],
            '--img', '416',                    # Same as training
            '--conf', '0.1',                   # Same as training
            '--iou-thres', '0.45',             # Same as training
            '--source', temp_image_path,
            '--project', temp_dir,
            '--name', 'results',
            '--exist-ok',
            '--save-txt',                      # Save detection coordinates
            '--save-conf'                      # Save confidence scores
        ]
        
        # Run YOLO detection
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=yolo_config['yolov5_path']
        )
        
        # Check for errors
        if result.returncode != 0:
            st.error(f"❌ YOLO detection failed!")
            st.code(result.stderr)
            return {
                'defect_count': 0,
                'defects': [],
                'annotated_image': image,
                'error': result.stderr
            }
        
        # Find output image
        output_dir = os.path.join(temp_dir, 'results')
        output_image_path = os.path.join(output_dir, "temp_image.jpg")
        
        # Find detection labels
        labels_dir = os.path.join(output_dir, 'labels')
        label_file = os.path.join(labels_dir, "temp_image.txt")
        
        defects = []
        
        # Parse detection results
        if os.path.exists(label_file):
            with open(label_file, 'r') as f:
                lines = f.readlines()
                
            # Get image dimensions
            img_width, img_height = image.size
            
            for line in lines:
                parts = line.strip().split()
                if len(parts) >= 5:
                    # YOLO format: class x_center y_center width height confidence
                    class_id = int(parts[0])
                    x_center = float(parts[1]) * img_width
                    y_center = float(parts[2]) * img_height
                    width = float(parts[3]) * img_width
                    height = float(parts[4]) * img_height
                    confidence = float(parts[5]) if len(parts) > 5 else 0.0
                    
                    # Convert to corner coordinates
                    x1 = int(x_center - width/2)
                    y1 = int(y_center - height/2)
                    x2 = int(x_center + width/2)
                    y2 = int(y_center + height/2)
                    
                    defects.append({
                        'bbox': [x1, y1, x2, y2],
                        'confidence': confidence
                    })
        
        st.write(f"- Total detections: {len(defects)}")
        
        if len(defects) > 0:
            for idx, defect in enumerate(defects, 1):
                st.write(f"  - Detection {idx}: conf={defect['confidence']:.3f}, box={defect['bbox']}")
        
        # Load annotated image
        annotated_image = image
        if os.path.exists(output_image_path):
            annotated_image = Image.open(output_image_path)
        
        return {
            'defect_count': len(defects),
            'defects': defects,
            'annotated_image': annotated_image
        }
    
    except Exception as e:
        st.error(f"⚠️ Error in YOLO detection: {e}")
        import traceback
        st.code(traceback.format_exc())
        
        return {
            'defect_count': 0,
            'defects': [],
            'annotated_image': image,
            'error': str(e)
        }
    
    finally:
        # Cleanup temporary files
        try:
            shutil.rmtree(temp_dir)
        except:
            pass


def render_image_inspection_tab():
    """Render the Image Inspection tab"""
    
    st.header("🔍 Equipment Image Inspection")
    st.markdown("Upload an equipment image to detect defects and locate their positions")
    
    # Initialize session state for uploaded file
    if 'uploaded_file_key' not in st.session_state:
        st.session_state.uploaded_file_key = 0
    
    # Load VGG model
    with st.spinner("Loading VGG16 model..."):
        vgg_model = load_vgg_model()
    
    # Check YOLO setup
    yolo_config = check_yolo_setup()
    
    # Display model status
    col1, col2 = st.columns(2)
    with col1:
        if vgg_model is not None:
            st.success("✅ VGG16 loaded")
        else:
            st.error("❌ VGG16 failed")
    
    with col2:
        if yolo_config['ready']:
            st.success("✅ YOLO ready")
        else:
            st.warning("⚠️ YOLO unavailable")
            
            if not yolo_config['yolo_exists']:
                st.error(f"❌ YOLOv5 folder not found at: {yolo_config['yolov5_path']}")
            if not yolo_config['weights_exists']:
                st.error(f"❌ Weights not found at: {yolo_config['weights_path']}")
            if not yolo_config['detect_exists']:
                st.error(f"❌ detect.py not found at: {yolo_config['detect_script']}")
    
    if vgg_model is None:
        st.error("❌ VGG16 model not loaded. Cannot proceed.")
        return
    
    st.markdown("---")
    
    # File uploader
    uploaded_file = st.file_uploader(
        "Choose an equipment image",
        type=['jpg', 'jpeg', 'png'],
        help="Upload a clear image of the equipment",
        key=f"uploader_{st.session_state.uploaded_file_key}"
    )
    
    if uploaded_file is not None:
        # Load image
        image = Image.open(uploaded_file)
        
        # Display original image
        st.subheader("📸 Original Image")
        st.image(image, caption=f"Uploaded: {uploaded_file.name}", use_container_width=True)
        
        # Auto-inspect option
        col1, col2 = st.columns([3, 1])
        
        with col1:
            auto_inspect = st.checkbox("🔄 Auto-inspect on upload", value=True, help="Automatically analyze image when uploaded")
        
        with col2:
            manual_button = st.button("🔍 Inspect Now", type="primary", use_container_width=True)
        
        # Perform inspection
        should_inspect = auto_inspect or manual_button
        
        if should_inspect:
            
            # Step 1: Classification
            with st.spinner("🤖 Analyzing image with VGG16..."):
                classification_result = classify_defect(vgg_model, image)
            
            st.markdown("---")
            st.subheader("📊 Classification Result")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if classification_result['is_defected']:
                    st.error(f"### 🔴 {classification_result['label']}")
                else:
                    st.success(f"### ✅ {classification_result['label']}")
            
            with col2:
                st.metric(
                    "Confidence",
                    f"{classification_result['confidence']:.1%}"
                )
            
            with col3:
                st.metric(
                    "Raw Probability",
                    f"{classification_result['probability']:.4f}",
                    help="VGG16 output (≥0.5 = Non-Defected)"
                )
            
            # Step 2: Localization if defected
            if classification_result['is_defected']:
                st.markdown("---")
                st.subheader("🎯 Defect Localization")
                
                if yolo_config['ready']:
                    with st.spinner("🔍 Running YOLO detection (using detect.py - same as training)..."):
                        yolo_result = locate_defect_yolo_subprocess(image, yolo_config)
                    
                    if yolo_result['defect_count'] > 0:
                        st.warning(f"⚠️ Found **{yolo_result['defect_count']}** defect(s)")
                        
                        st.image(
                            yolo_result['annotated_image'],
                            caption="Defects Located (YOLO Detection)",
                            use_container_width=True
                        )
                        
                        with st.expander("📋 Detailed Defect Information"):
                            for i, defect in enumerate(yolo_result['defects'], 1):
                                st.write(f"**Defect {i}:**")
                                st.write(f"- Position (x1, y1, x2, y2): {defect['bbox']}")
                                st.write(f"- Confidence: {defect['confidence']:.2%}")
                                st.write("---")
                        
                        st.error("""
                        ### 🚨 Recommended Actions:
                        - Schedule immediate inspection
                        - Review maintenance history
                        - Consider equipment replacement if multiple defects
                        - Document defect location for maintenance team
                        """)
                    
                    else:
                        st.info("ℹ️ VGG classified as defected but YOLO detected no specific regions")
                        st.warning("""
                        **Possible reasons:**
                        - Overall wear or degradation (not localized)
                        - Very small defects below detection threshold
                        - Defect type not in YOLO training data
                        - Low confidence detections filtered out
                        
                        **Recommendation:** Manual inspection recommended
                        """)
                
                else:
                    st.warning("⚠️ Defect detected but YOLO model unavailable")
                    st.info("""
                    **VGG Classification:** Defect detected
                    
                    **Recommendations:**
                    - Schedule manual inspection
                    - Review equipment history
                    - Set up YOLO for precise defect location
                    """)
            
            else:
                st.markdown("---")
                st.success("""
                ### ✅ Equipment Status: Normal
                
                No defects detected. Equipment appears to be in good condition.
                
                **Recommendations:**
                - Continue regular maintenance schedule
                - Re-inspect after standard operating period
                - Keep equipment monitoring logs updated
                """)
            
            # Add separator and new upload button
            st.markdown("---")
            if st.button("📤 Upload Another Image", use_container_width=True):
                st.session_state.uploaded_file_key += 1
                st.rerun()


def render_batch_inspection_tab():
    """Batch inspection for multiple images"""
    
    st.header("📦 Batch Image Inspection")
    st.info("Upload multiple images for batch processing")
    
    uploaded_files = st.file_uploader(
        "Choose multiple equipment images",
        type=['jpg', 'jpeg', 'png'],
        accept_multiple_files=True
    )
    
    if uploaded_files:
        st.write(f"📁 Uploaded **{len(uploaded_files)}** images")
        
        # Options
        col1, col2 = st.columns(2)
        with col1:
            include_yolo = st.checkbox("Include YOLO defect count", value=True)
        with col2:
            show_preview = st.checkbox("Show image previews", value=False)
        
        if st.button("🔍 Inspect All Images", type="primary", use_container_width=True):
            
            vgg_model = load_vgg_model()
            yolo_config = check_yolo_setup()
            
            if vgg_model is None:
                st.error("❌ VGG16 model not loaded")
                return
            
            results = []
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            for idx, file in enumerate(uploaded_files):
                status_text.text(f"Processing {idx+1}/{len(uploaded_files)}: {file.name}")
                
                image = Image.open(file)
                
                # Show preview if enabled
                if show_preview:
                    with st.expander(f"Preview: {file.name}"):
                        st.image(image, use_container_width=True)
                
                # Classify
                class_result = classify_defect(vgg_model, image)
                
                result = {
                    'filename': file.name,
                    'label': class_result['label'],
                    'confidence': class_result['confidence'],
                    'defect_count': 0
                }
                
                # Count defects with YOLO if defected
                if include_yolo and class_result['is_defected'] and yolo_config['ready']:
                    yolo_result = locate_defect_yolo_subprocess(image, yolo_config)
                    result['defect_count'] = yolo_result['defect_count']
                
                results.append(result)
                progress_bar.progress((idx + 1) / len(uploaded_files))
            
            status_text.text("✅ Processing complete!")
            
            # Display results
            import pandas as pd
            results_df = pd.DataFrame(results)
            
            st.markdown("---")
            st.subheader("📊 Batch Inspection Results")
            
            # Summary metrics
            col1, col2, col3 = st.columns(3)
            
            defected_count = (results_df['label'] == 'Defected').sum()
            total_defects = results_df['defect_count'].sum() if include_yolo else 0
            
            with col1:
                st.metric("Total Images", len(results_df))
            with col2:
                st.metric("Defected", defected_count, delta=f"{defected_count/len(results_df)*100:.1f}%")
            with col3:
                if include_yolo:
                    st.metric("Total Defects Found", int(total_defects))
            
            # Results table
            st.dataframe(
                results_df.style.applymap(
                    lambda x: 'background-color: #ffcccc' if x == 'Defected' else '',
                    subset=['label']
                ),
                use_container_width=True
            )
            
            # Download button
            csv = results_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Results as CSV",
                data=csv,
                file_name="batch_inspection_results.csv",
                mime="text/csv",
                use_container_width=True
            )


# Main function to be called from app.py
def main():
    """Main function for standalone testing"""
    st.set_page_config(
        page_title="Image Inspection",
        page_icon="🔍",
        layout="wide"
    )
    
    # Sidebar for navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Choose Mode", ["Single Image", "Batch Processing"])
    
    if page == "Single Image":
        render_image_inspection_tab()
    else:
        render_batch_inspection_tab()


if __name__ == "__main__":
    main()