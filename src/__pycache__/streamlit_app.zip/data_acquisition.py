"""
Data Acquisition Script
Downloads dataset from Kaggle and saves locally
Run once to get the raw data
"""

import kagglehub
import pandas as pd


def save_data(destination_folder: str = "data"):
    """Download and save dataset from Kaggle"""
    # Download from Kaggle
    path = kagglehub.dataset_download(
        "arnabbiswas1/microsoft-azure-predictive-maintenance"
    )
    print("\nPath to dataset files:", path)

    # Load datasets
    telemetry_df = pd.read_csv(f"{path}/PdM_telemetry.csv", parse_dates=["datetime"])
    errors_df = pd.read_csv(f"{path}/PdM_errors.csv", parse_dates=["datetime"])
    maint_df = pd.read_csv(f"{path}/PdM_maint.csv", parse_dates=["datetime"])
    failures_df = pd.read_csv(f"{path}/PdM_failures.csv", parse_dates=["datetime"])
    machines_df = pd.read_csv(f"{path}/PdM_machines.csv")

    # Sort by machineID and datetime
    for df in [telemetry_df, maint_df, failures_df, errors_df]:
        df.sort_values(["machineID", "datetime"], inplace=True)

    # Save to CSV
    telemetry_df.to_csv(f"{destination_folder}/telemetry.csv", index=False)
    errors_df.to_csv(f"{destination_folder}/errors.csv", index=False)
    maint_df.to_csv(f"{destination_folder}/maint.csv", index=False)
    failures_df.to_csv(f"{destination_folder}/failures.csv", index=False)
    machines_df.to_csv(f"{destination_folder}/machines.csv", index=False)


def load_data() -> tuple:
    """Load datasets from CSV files"""
    telemetry_df = pd.read_csv("data/raw/telemetry.csv", parse_dates=["datetime"])
    errors_df = pd.read_csv("data/raw/errors.csv", parse_dates=["datetime"])
    maint_df = pd.read_csv("data/raw/maint.csv", parse_dates=["datetime"])
    failures_df = pd.read_csv("data/raw/failures.csv", parse_dates=["datetime"])
    machines_df = pd.read_csv("data/raw/machines.csv")

    return telemetry_df, errors_df, maint_df, failures_df, machines_df


if __name__ == "__main__":
    save_data("data/raw")
