"""
Feature Engineering Module
Handles sensor feature extraction and data preprocessing
"""

import pandas as pd
import numpy as np

# Constants
SENSORS = ["volt", "rotate", "pressure", "vibration"]
LAGS = [1, 3, 6, 12, 24]
ROLL_MEANS = [3, 6, 12, 24, 48]
ROLL_STDS = [6, 24, 48]
SLOPES_K = [3, 6, 12]


def add_sensor_features(df, sensors, lags, rmeans, rstds, slopes):
    """Add lag, rolling mean, rolling std, and slope features"""
    out = df.copy()
    g = out.groupby("machineID", group_keys=False)

    # Lag features
    for c in sensors:
        for k in lags:
            out[f"{c}_lag_{k}h"] = g[c].shift(k)

    # Rolling means
    for c in sensors:
        for k in rmeans:
            out[f"{c}_mean_{k}h"] = (
                g[c].rolling(window=k, min_periods=k).mean()
                 .reset_index(level=0, drop=True)
            )

    # Rolling standard deviations
    for c in sensors:
        for k in rstds:
            out[f"{c}_std_{k}h"] = (
                g[c].rolling(window=k, min_periods=k).std(ddof=0)
                 .reset_index(level=0, drop=True)
            )

    # Slope features
    for c in sensors:
        for k in slopes:
            lag_col = f"{c}_lag_{k}h"
            if lag_col not in out.columns:
                out[lag_col] = g[c].shift(k)
            out[f"{c}_slope_{k}h"] = (out[c] - out[lag_col]) / k

    return out


def process_telemetry(df: pd.DataFrame) -> pd.DataFrame:
    """Complete preprocessing pipeline for telemetry data"""
    out = df.copy()

    # Parse datetime
    if 'datetime' in out.columns and out['datetime'].dtype == 'object':
        out['datetime'] = pd.to_datetime(out['datetime'])

    # Add default values
    if 'model' not in out.columns:
        out['model'] = 'model1'
    if 'age' not in out.columns:
        out['age'] = 18

    # Handle single row - create dummy rows for rolling windows
    if len(out) < 50:
        original_row = out.iloc[0].copy()
        dummy_rows = []
        
        for i in range(49):
            row = original_row.copy()
            if 'datetime' in out.columns:
                row['datetime'] = pd.to_datetime(row['datetime']) - pd.Timedelta(hours=49-i)
            dummy_rows.append(row)
        
        dummy_df = pd.DataFrame(dummy_rows)
        out = pd.concat([dummy_df, out], ignore_index=True)

    # Add dummy target columns
    out["will_fail_in_24h"] = 0
    out["will_fail_in_48h"] = 0

    # Add dummy error columns
    for e in ["error1", "error2", "error3", "error4", "error5"]:
        out[f"{e}_last_24h"] = 0
        out[f"{e}_last_48h"] = 0

    # Add dummy maintenance columns
    for c in ["comp1", "comp2", "comp3", "comp4"]:
        out[f"time_since_maint_{c}_h"] = 48.0
        out[f"time_since_maint_{c}_d"] = 2.0

    # Add sensor features
    out = add_sensor_features(out, SENSORS, LAGS, ROLL_MEANS, ROLL_STDS, SLOPES_K)

    # Fill missing values
    numeric_cols = out.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if out[col].isna().any():
            out[col] = out[col].fillna(out[col].median())

    # Convert model to category
    if 'model' in out.columns:
        out['model'] = out['model'].astype('category')

    # Select feature columns only
    exclude = {"datetime", "machineID", "will_fail_in_24h", "will_fail_in_48h"}
    features = [c for c in out.columns if c not in exclude]
    
    return out.loc[:, features].tail(1).copy()
