"""
Utility functions for data processing and model training
Used by preprocessing and training scripts only
"""

import os
import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from collections import OrderedDict
from pathlib import Path
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.metrics import (
    roc_curve, roc_auc_score, classification_report, confusion_matrix,
    average_precision_score, precision_recall_curve, fbeta_score,
    precision_score, recall_score, f1_score, accuracy_score
)
from uuid import uuid4

# Global seed for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
os.environ["PYTHONHASHSEED"] = str(SEED)
RANDOM_STATE = 42


# ===== Custom Transformers =====

class ToFloat32(BaseEstimator, TransformerMixin):
    """Cast to float32 for memory efficiency"""
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        return X.astype(np.float32)


# ===== Plotting Functions =====

def plot_hist(df, feature_name, log=False, bins=100):
    """Plot histogram of a feature"""
    plt.figure(figsize=(10, 6))
    if log:
        plt.hist(df[feature_name].dropna(), bins=bins, log=True)
    else:
        plt.hist(df[feature_name].dropna(), bins=bins)
    plt.title(f"Distribution of {feature_name}")
    plt.xlabel(feature_name)
    plt.ylabel("Frequency")
    plt.grid()
    plt.savefig(f"data/graphs/histogram-{feature_name}.png")


def plot_barh(df, feature_name, log=False, title="", xlabel=""):
    """Plot horizontal bar chart"""
    plt.figure(figsize=(10, 6))
    if log:
        df[feature_name].value_counts().plot(kind="barh", logx=True)
    else:
        df[feature_name].value_counts().plot(kind="barh")
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(feature_name)
    plt.savefig(f"data/graphs/barh-{feature_name}-{title}.png")


def plot_grouped_bar(df, index, columns, values, title=None, xlabel="", ylabel=""):
    """Plot grouped bar chart"""
    df_temp = df.groupby([index, columns]).size().reset_index()
    df_temp.columns = [index, columns, values]
    df_pivot = pd.pivot(df_temp, index=index, columns=columns, values=values).rename_axis(None, axis=1)
    df_pivot.plot.bar(stacked=True, figsize=(20, 6), title=title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.savefig(f"data/graphs/{title}-{xlabel}-{ylabel}-{uuid4()}.png")


def plot_roc(y_true, y_prob, title):
    """Plot ROC curve"""
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    auc = roc_auc_score(y_true, y_prob)
    plt.figure(figsize=(5, 4))
    plt.plot(fpr, tpr, label=f"AUC={auc:.3f}")
    plt.plot([0, 1], [0, 1], "--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.savefig(f"data/graphs/roc-curve-{title}-{uuid4()}.png")


# ===== Data Processing Functions =====

def check_future_failure(current_time, failure_times, window_hours):
    """Check if machine will fail within time window"""
    if not failure_times:
        return 0
    window = pd.Timedelta(hours=window_hours)
    for ft in failure_times:
        dt = ft - current_time
        if pd.Timedelta(0) <= dt <= window:
            return 1
    return 0


def add_error_flags_per_machine(telemetry_df, errors_df, error_label):
    """Add error flags for 24h and 48h windows"""
    timecol = f"{error_label}_time"
    telemetry_df[f"{error_label}_last_24h"] = 0
    telemetry_df[f"{error_label}_last_48h"] = 0
    e = errors_df[errors_df["errorID"] == error_label].rename(columns={"datetime": timecol})

    machine_ids = telemetry_df["machineID"].unique().tolist()

    for m in machine_ids:
        left_mask = telemetry_df["machineID"] == m
        left = telemetry_df.loc[left_mask, ["datetime"]].sort_values("datetime")
        right = e.loc[e["machineID"] == m, [timecol]].sort_values(timecol)
        if right.empty:
            continue

        merged = pd.merge_asof(
            left, right, left_on="datetime", right_on=timecol,
            direction="backward", allow_exact_matches=True
        )
        delta_h = (merged["datetime"] - merged[timecol]).dt.total_seconds() / 3600.0
        has_prev = merged[timecol].notna()
        telemetry_df.loc[left.index, f"{error_label}_last_24h"] = (
            ((delta_h <= 24) & has_prev).astype(int).values
        )
        telemetry_df.loc[left.index, f"{error_label}_last_48h"] = (
            ((delta_h <= 48) & has_prev).astype(int).values
        )

    return telemetry_df


def add_time_since_maint(telemetry_df, maint_df, comp_label):
    """Add time since last maintenance for component"""
    timecol = f"{comp_label}_maint_time"
    telemetry_df[f"time_since_maint_{comp_label}_h"] = pd.NA
    telemetry_df[f"time_since_maint_{comp_label}_d"] = pd.NA

    m = maint_df[maint_df["comp"] == comp_label].rename(columns={"datetime": timecol})
    machine_ids = telemetry_df["machineID"].unique().tolist()

    for m_id in machine_ids:
        left_mask = telemetry_df["machineID"] == m_id
        left = telemetry_df.loc[left_mask, ["datetime"]].sort_values("datetime")
        right = m.loc[m["machineID"] == m_id, [timecol]].sort_values(timecol)

        if right.empty:
            continue

        merged = pd.merge_asof(
            left, right, left_on="datetime", right_on=timecol,
            direction="backward", allow_exact_matches=True
        )
        delta_h = (merged["datetime"] - merged[timecol]).dt.total_seconds() / 3600.0
        telemetry_df.loc[left.index, f"time_since_maint_{comp_label}_h"] = delta_h.values
        telemetry_df.loc[left.index, f"time_since_maint_{comp_label}_d"] = (delta_h / 24).values

    return telemetry_df


def add_sensor_features(df, sensors, lags, rmeans, rstds, slopes):
    """Add lag, rolling mean, rolling std, and slope features"""
    g = df.groupby("machineID", group_keys=False)
    
    for c in sensors:
        for k in lags:
            df[f"{c}_lag_{k}h"] = g[c].shift(k)
    
    for c in sensors:
        for k in rmeans:
            df[f"{c}_mean_{k}h"] = (
                g[c].rolling(window=k, min_periods=k).mean()
                .reset_index(level=0, drop=True)
            )
    
    for c in sensors:
        for k in rstds:
            df[f"{c}_std_{k}h"] = (
                g[c].rolling(window=k, min_periods=k).std(ddof=0)
                .reset_index(level=0, drop=True)
            )
    
    for c in sensors:
        for k in slopes:
            lag_col = f"{c}_lag_{k}h"
            if lag_col not in df.columns:
                df[lag_col] = g[c].shift(k)
            df[f"{c}_slope_{k}h"] = (df[c] - df[lag_col]) / k
    
    return df


# ===== Model Training Functions =====

def build_split(X, y, train_mask, val_mask, test_mask, label, timestamps):
    """Build train/val/test splits"""
    ds = OrderedDict()
    ds[f"X_train_{label}"] = X[train_mask]
    ds[f"y_train_{label}"] = y[train_mask]
    ds[f"X_val_{label}"] = X[val_mask]
    ds[f"y_val_{label}"] = y[val_mask]
    ds[f"X_test_{label}"] = X[test_mask]
    ds[f"y_test_{label}"] = y[test_mask]

    print(f"\n== {label.upper()} ===")
    for split in ["train", "val", "test"]:
        y_split = ds[f"y_{split}_{label}"]
        pos = int(y_split.sum())
        n = int(y_split.shape[0])
        prop = pos / max(n, 1)
        print(f"{split:>5}: n={n:,} | positives={pos:,} ({prop: .4%})")

    for split, mask in [("train", train_mask), ("val", val_mask), ("test", test_mask)]:
        print(f"{split:>5} range: {timestamps[mask].min()} → {timestamps[mask].max()}")

    return ds


def best_threshold_by_fbeta(y_true, y_prob, beta=2.0):
    """Find optimal threshold for F-beta score"""
    p, r, t = precision_recall_curve(y_true, y_prob)
    t = np.r_[t, 1.0]
    fbeta = (1 + beta**2) * (p * r) / (beta**2 * p + r + 1e-12)
    idx = np.nanargmax(fbeta)
    return float(t[idx]), float(fbeta[idx])


def metrics_block(y_true, y_prob, threshold):
    """Calculate all metrics"""
    y_pred = (y_prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    specificity = tn / (tn + fp + 1e-12)
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred),
        "specificity": specificity,
        "f1": f1_score(y_true, y_pred),
        "f2": fbeta_score(y_true, y_pred, beta=2.0),
        "roc_auc": roc_auc_score(y_true, y_prob),
        "pr_auc": average_precision_score(y_true, y_prob),
        "tp": tp, "fp": fp, "tn": tn, "fn": fn,
    }


def print_confmat(y_true, y_prob, threshold, title):
    """Print confusion matrix and classification report"""
    y_pred = (y_prob >= threshold).astype(int)
    cm = confusion_matrix(y_true, y_pred)
    print(f"\n{title} | threshold={threshold:.3f}")
    print(cm)
    print(classification_report(y_true, y_pred, digits=4))
